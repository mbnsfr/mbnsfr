# Upload Your GitHub Profile

Your profile repository must be public and named exactly `mbnsfr`.

## Upload through the GitHub website

1. Open `https://github.com/mbnsfr/mbnsfr`.
2. Select **Add file → Upload files**.
3. Upload `README.md`.
4. Upload the entire `assets` folder, keeping this exact path:

   `assets/kado-cat-laptop.gif`

5. Enter the commit message:

   `Create professional GitHub profile`

6. Select **Commit changes**.
7. Open `https://github.com/mbnsfr` and refresh the **Overview** tab.

## Important

- Do not rename `README.md`.
- Keep the `assets` folder name lowercase.
- Keep the repository public.
- If one of the featured-project links does not match the final repository name, edit only that URL in the **Featured Projects** table.
- When the Speech Emotion Recognition or Kado Digital repository becomes public, replace the “In progress” note with a direct project link.
